# Arteteco Design System

Personal website of **Manuel Moscariello** — Italian adventurer, ecologist, maker.  
Live at **arteteco.com** · GitHub: [arteteco/arteteco.github.io](https://github.com/arteteco/arteteco.github.io)

---

## About the Person / Product

Manuel is an ecologist, president of ASNU (Associazione Scienze Naturali Unite), and self-described "avventuriero per gioco" (adventurer for fun). He builds things that don't exist yet (like a railbike for abandoned railway lines), goes to forgotten places, writes games, and plays instruments the wrong way. The website is a personal blog/portfolio combining adventure writing, nature, music, tabletop RPGs, and DIY construction.

**Site tech:** Astro v6, Tailwind via @tailwindcss/vite, GitHub Pages, GitHub Actions CD.

**Surfaces represented:**
- `arteteco.com` — personal website / blog (single surface)

**Sources provided:**
- GitHub repo: https://github.com/arteteco/arteteco.github.io (main source of truth)
- No Figma design files were provided

---

## CONTENT FUNDAMENTALS

**Language:** Italian throughout — headings, nav, body, labels, footer.

**Tone:** Dry, honest, slightly poetic. First-person singular ("costruisco", "vado", "scrivo"). Never corporate. Prefers concrete specifics over abstractions ("una railbike per ferrovie abbandonate" vs "innovative projects").

**Casing:**
- Nav links: lowercase monospace, letter-spaced (`chi sono`)
- Section labels: prefixed with `//` in monospace uppercase (`// Tutto`, `// Pensieri brevi`)
- Post tags: all-lowercase monospace with letter-spacing (`viaggi`, `natura`)
- Hero/titles: normal sentence or proper noun casing

**Voice:** Intimate, slightly wry. Says "I" directly. Avoids buzzwords. Embraces imperfection ("suono strumenti nel modo sbagliato" — I play instruments the wrong way). The tagline "Avventuriero per gioco" is playful and self-aware.

**Emoji:** Not used anywhere. Zero.

**Links/CTA language:** Short, italicized or mono-styled. E.g. `leggi su mastodon →` — lowercase, arrow suffix.

**Content categories (tags):** viaggi · musica · gdr · natura · costruzione

**Vibe:** Someone who does things for the love of it, documents honestly, and shares without performative polish.

---

## VISUAL FOUNDATIONS

**Color palette:**
- Background: near-black with warm undertone (`#0e0e0d`) — not pure black
- Surfaces stack: `#0e0e0d` → `#151513` → `#1c1c1a` on hover
- Borders: `#2a2a27` — very subtle, warm-gray
- Text: warm off-white `#e8e4dc`, muted gray `#7a7870`
- **Primary accent:** sage green `#7fb87e` / dark green `#5a8a5e`
- **Secondary accent:** warm gold/amber `#a8864e`
- Green is used for: links, section labels, active states, card title hover, tag borders, nav logo
- Gold is used for: footer links, "leggi su mastodon →" links

**Typography:**
- **Playfair Display** (serif) — hero name (900w), hero tagline (700 italic), post titles, section h2s, profile heading. Gives a literary/editorial feel.
- **DM Mono** — nav links, section labels, tags, dates, social icons, footer. Gives a technical/precise feel.
- **DM Sans** (300w) — body text, excerpts, prose. Light weight; very readable.

**Backgrounds:**
- Dark solid, no patterns or textures
- Hero uses a subtle dark radial gradient with faint green tint at top-right
- Post cover images with a gradient overlay (transparent → dark, bottom-half) for text legibility
- No full-bleed hero photography (intentionally left as flat dark color)

**Layout:**
- Max content width: ~1100px, centered
- Sticky nav, 1px solid border bottom
- Profile section: 2-col grid (200px photo col + prose)
- Posts: 3-col grid, **separated by 1px gaps** (background of grid is `--border` color — elegant hairline dividers)
- Mastodon thoughts: same 3-col grid pattern
- Mobile: single column throughout

**Grid dividers:** The 1px-gap + border-color background trick is a signature motif — cards butt up against each other with only a hairline between them. No card shadows or rounded corners.

**Cards:**
- Flat, square corners (border-radius: 0)
- Background transitions from `--bg` → `--surface` on hover
- Cover image with gradient overlay, then padded body below
- No drop shadows

**Animation / transitions:**
- Minimal: `transition: color 0.3s`, `transition: background 0.3s`, `transition: filter 0.4s`
- No bounces, springs, or dramatic motion
- Profile photo: grayscale(20%) → grayscale(0%) on hover

**Hover states:**
- Text links: color shifts to `--green`
- Cards: background lightens slightly
- Nav links: muted → green
- Social icon circles: border + text color → green

**Borders:**
- Thin 1px lines only, using `--border` (#2a2a27) or `--green2` (#5a8a5e)
- Profile photo: 2px solid `--green2`
- Social circles: 1px solid `--border`, → `--green` on hover
- Post tags: 1px solid `--green2`

**Corner radii:** Zero. No rounded corners anywhere. Strictly rectangular.

**Shadows:** None.

**Iconography:** No icon font, no SVG icons. Social links are 2-letter abbreviations in DM Mono circles (`ig`, `yt`). No emoji.

**Imagery vibe:** Documentary / field photography. Warm or neutral tones. Slightly desaturated profile photo. Adventure & nature subjects.

**Spacing rhythm:** Generous padding within sections (2–3rem). Tight internal card padding (1.2–1.5rem).

**Position:** Nav is `position: sticky; top: 0` with bg blur-free solid fill.

---

## ICONOGRAPHY

**Approach:** Deliberately iconography-free. No icon font, no SVG icon library, no emoji.

**Social links** are rendered as 2–3 character monospace abbreviations inside 38×38px circles:
- `ig` → Instagram
- `yt` → YouTube

**Section labels** use `//` prefix as a pseudo-icon convention (code comment style).

**Arrow suffix** `→` is used inline in text links (plain unicode).

**Assets in `assets/`:**
- `foto.png` — circular profile photo of Manuel
- `favicon.svg` — site favicon (rocket SVG from Astro starter — likely to be replaced)
- `favicon.png` — actual favicon used (in /img/)
- `assets/img/inizio.jpg` — post cover image (adventure/nature)
- `assets/img/railbike.jpg` — railbike project cover
- `assets/img/railbike01.png` — railbike build photo
- `assets/img/lucien.png` — travel/adventure post cover

---

## Files Index

| Path | Description |
|---|---|
| `README.md` | This file — design system overview |
| `colors_and_type.css` | All CSS custom properties + semantic type classes |
| `SKILL.md` | Agent skill descriptor |
| `assets/` | Logos, profile photo, post images |
| `preview/` | Design system card previews (registered in Design System tab) |
| `ui_kits/website/` | Hi-fi UI kit for arteteco.com |
| `ui_kits/website/index.html` | Interactive website prototype |
