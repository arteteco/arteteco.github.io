// ThoughtCard.jsx — Mastodon thought cards
const ThoughtCard = ({ thought }) => {
  const [hover, setHover] = React.useState(false);
  const s = {
    card: { background: hover ? 'var(--surface)' : 'var(--bg)', padding:'1.4rem 1.5rem 1.2rem', display:'flex', flexDirection:'column', gap:'0.8rem', transition:'background 0.3s' },
    date: { fontFamily:'var(--fm)', fontSize:'0.66rem', color:'var(--muted)' },
    content: { fontSize:'0.88rem', color:'var(--text)', lineHeight:1.7, flex:1 },
    link: { fontFamily:'var(--fm)', fontSize:'0.62rem', letterSpacing:'0.1em', textTransform:'uppercase', color:'var(--gold)', textDecoration:'none', alignSelf:'flex-start', cursor:'pointer' },
  };
  return (
    <div style={s.card} onMouseEnter={()=>setHover(true)} onMouseLeave={()=>setHover(false)}>
      <span style={s.date}>{thought.date}</span>
      <div style={s.content}><p>{thought.content}</p></div>
      <span style={s.link}>leggi su mastodon →</span>
    </div>
  );
};

const ThoughtsSection = ({ thoughts }) => {
  if (!thoughts || thoughts.length === 0) return null;
  const s = {
    section: { padding:'3rem 2rem', maxWidth:'1100px', margin:'0 auto' },
    label: { fontFamily:'var(--fm)', fontSize:'0.72rem', letterSpacing:'0.3em', textTransform:'uppercase', color:'var(--green)' },
    grid: { display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'1px', background:'var(--border)', marginTop:'2rem' },
  };
  return (
    <section style={s.section}>
      <p style={s.label}>// Pensieri brevi</p>
      <div style={s.grid}>
        {thoughts.map(t => <ThoughtCard key={t.id} thought={t} />)}
      </div>
    </section>
  );
};

Object.assign(window, { ThoughtCard, ThoughtsSection });
