// PostCard.jsx — blog post card + grid + tag filter
const PostCard = ({ post, onClick }) => {
  const [hover, setHover] = React.useState(false);
  const s = {
    card: { background: hover ? 'var(--surface)' : 'var(--bg)', textDecoration:'none', display:'block', position:'relative', transition:'background 0.3s', overflow:'hidden', cursor:'pointer' },
    img: { width:'100%', height:180, background:'var(--bg2)', position:'relative', overflow:'hidden' },
    imgEl: { width:'100%', height:'100%', objectFit:'cover', display:'block' },
    overlay: { display:'none' },
    noImg: { width:'100%', height:'100%', display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'var(--fm)', fontSize:'0.55rem', color:'var(--border)', letterSpacing:'0.08em' },
    body: { padding:'1.2rem 1.5rem 1.5rem' },
    meta: { display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'0.7rem', flexWrap:'wrap', gap:'0.4rem' },
    date: { fontFamily:'var(--fm)', fontSize:'0.68rem', color:'var(--muted)' },
    tags: { display:'flex', gap:'0.3rem', flexWrap:'wrap' },
    tag: { fontFamily:'var(--fm)', fontSize:'0.62rem', letterSpacing:'0.12em', textTransform:'uppercase', padding:'0.2rem 0.5rem', border:'1px solid', color:'var(--green)', borderColor:'var(--green2)' },
    title: { fontFamily:'var(--fd)', fontSize:'1.05rem', fontWeight:700, color: hover ? 'var(--green)' : 'var(--text)', lineHeight:1.3, transition:'color 0.3s' },
    excerpt: { fontSize:'0.84rem', color:'var(--muted)', lineHeight:1.6, marginTop:'0.5rem' },
  };
  return (
    <div style={s.card} onMouseEnter={()=>setHover(true)} onMouseLeave={()=>setHover(false)} onClick={onClick}>
      <div style={s.img}>
        {post.cover ? <img src={post.cover} alt={post.title} style={s.imgEl} /> : <div style={s.noImg}>immagine</div>}
        <div style={s.overlay} />
      </div>
      <div style={s.body}>
        <div style={s.meta}>
          <span style={s.date}>{post.date}</span>
          <div style={s.tags}>{post.tags.map(t => <span key={t} style={s.tag}>{t}</span>)}</div>
        </div>
        <h3 style={s.title}>{post.title}</h3>
        {post.excerpt && <p style={s.excerpt}>{post.excerpt}</p>}
      </div>
    </div>
  );
};

const PostGrid = ({ posts }) => {
  const allTags = [...new Set(posts.flatMap(p => p.tags))].sort();
  const [activeTag, setActiveTag] = React.useState('tutti');

  const visible = activeTag === 'tutti' ? posts : posts.filter(p => p.tags.includes(activeTag));

  const s = {
    section: { padding:'3rem 2rem', maxWidth:'1100px', margin:'0 auto' },
    header: { display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'2rem', flexWrap:'wrap', gap:'1rem' },
    label: { fontFamily:'var(--fm)', fontSize:'0.72rem', letterSpacing:'0.3em', textTransform:'uppercase', color:'var(--green)' },
    filters: { display:'flex', gap:'0.5rem', flexWrap:'wrap' },
    filterBtn: (active) => ({ fontFamily:'var(--fm)', fontSize:'0.68rem', letterSpacing:'0.12em', textTransform:'uppercase', color: active ? 'var(--green)' : 'var(--muted)', border:`1px solid ${active ? 'var(--green)' : 'var(--border)'}`, padding:'0.3rem 0.7rem', cursor:'pointer', transition:'all 0.3s', background:'none' }),
    grid: { display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'1px', background:'var(--border)' },
  };

  return (
    <section style={s.section}>
      <div style={s.header}>
        <p style={s.label}>// Tutto</p>
        <div style={s.filters}>
          {['tutti', ...allTags].map(tag => (
            <button key={tag} style={s.filterBtn(activeTag===tag)} onClick={()=>setActiveTag(tag)}>{tag}</button>
          ))}
        </div>
      </div>
      <div style={s.grid}>
        {visible.map(p => <PostCard key={p.id} post={p} />)}
      </div>
    </section>
  );
};

Object.assign(window, { PostCard, PostGrid });
