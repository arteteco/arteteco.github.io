// Hero.jsx — full-height hero section
const Hero = () => {
  const s = {
    hero: {
      background: 'linear-gradient(150deg, #eef5ee 0%, #f5f2ec 55%, #f0ede4 100%)',
      padding: '5rem 2rem 4rem',
      position: 'relative',
      overflow: 'hidden',
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'flex-end',
    },
    before: {
      position: 'absolute', top: 0, right: 0, width: '50%', height: '100%',
      background: 'radial-gradient(ellipse at right top, rgba(58,122,58,0.07) 0%, transparent 65%)',
      pointerEvents: 'none',
    },
    name: {
      fontFamily: 'var(--fd)', fontSize: 'clamp(2.5rem,6vw,4.5rem)', fontWeight: 900,
      color: 'var(--text)', lineHeight: 1, marginBottom: '0.5rem',
      letterSpacing: '-0.02em', position: 'relative',
    },
    tagline: {
      fontFamily: 'var(--fd)', fontSize: 'clamp(1.2rem,3vw,2rem)', fontWeight: 700,
      fontStyle: 'italic', color: 'var(--green)', lineHeight: 1, position: 'relative',
    },
  };
  return (
    <section style={s.hero}>
      <div style={s.before} />
      <h1 style={s.name}>Manuel Moscariello</h1>
      <p style={s.tagline}>Avventuriero per gioco</p>
    </section>
  );
};
Object.assign(window, { Hero });
