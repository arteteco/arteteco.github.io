// Nav.jsx — arteteco navigation bar
const Nav = ({ activeLink = null, onLogoClick = null }) => {
  const s = {
    nav: { display:'flex', justifyContent:'space-between', alignItems:'center', padding:'1.2rem 2rem', borderBottom:'1px solid var(--border)', background:'var(--bg)', position:'sticky', top:0, zIndex:100 },
    logo: { fontFamily:'var(--fm)', fontSize:'0.9rem', letterSpacing:'0.2em', color:'var(--green)', textDecoration:'none', textTransform:'uppercase', cursor: onLogoClick ? 'pointer' : 'default' },
    links: { display:'flex', gap:'2rem', listStyle:'none' },
    link: { fontFamily:'var(--fm)', fontSize:'0.82rem', letterSpacing:'0.12em', textTransform:'uppercase', color:'var(--muted)', textDecoration:'none', transition:'color 0.3s', cursor:'pointer' },
    linkActive: { color:'var(--green)' },
  };
  const [hover, setHover] = React.useState(null);
  return (
    <nav style={s.nav}>
      <span style={s.logo} onClick={onLogoClick || undefined}>arteteco</span>
      <ul style={s.links}>
        {['Chi sono'].map(l => (
          <li key={l}>
            <span
              style={{...s.link, ...(hover===l || activeLink===l ? s.linkActive : {})}}
              onMouseEnter={() => setHover(l)}
              onMouseLeave={() => setHover(null)}
            >{l}</span>
          </li>
        ))}
      </ul>
    </nav>
  );
};
Object.assign(window, { Nav });
