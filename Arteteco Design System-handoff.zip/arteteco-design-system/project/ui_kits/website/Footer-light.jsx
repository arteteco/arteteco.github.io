// Footer.jsx
const Footer = () => {
  const s = {
    footer: { borderTop:'1px solid var(--border)', padding:'2rem', display:'flex', justifyContent:'space-between' },
    text: { fontFamily:'var(--fm)', fontSize:'0.72rem', color:'var(--muted)', letterSpacing:'0.1em' },
    link: { fontFamily:'var(--fm)', fontSize:'0.72rem', color:'var(--gold)', textDecoration:'none' },
  };
  return (
    <footer style={s.footer}>
      <p style={s.text}>© Manuel Moscariello</p>
      <a style={s.link}>arteteco.com</a>
    </footer>
  );
};
Object.assign(window, { Footer });
