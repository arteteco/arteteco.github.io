// Profile.jsx — 2-col profile section
const Profile = () => {
  const [photoHover, setPhotoHover] = React.useState(false);
  const [socialHover, setSocialHover] = React.useState(null);

  const s = {
    section: { display:'grid', gridTemplateColumns:'200px 1fr', gap:'3rem', alignItems:'start', padding:'3rem 2rem', borderBottom:'1px solid var(--border)', maxWidth:'1100px', margin:'0 auto' },
    left: { display:'flex', flexDirection:'column', alignItems:'center', gap:'1.2rem' },
    photo: { width:160, height:160, borderRadius:'50%', objectFit:'cover', border:'2px solid var(--green2)', filter: photoHover ? 'grayscale(0%)' : 'grayscale(20%)', transition:'filter 0.4s', cursor:'default' },
    socials: { display:'flex', gap:'0.6rem' },
    socialBtn: (id) => ({ width:38, height:38, border:`1px solid ${socialHover===id ? 'var(--green)' : 'var(--border)'}`, borderRadius:'50%', display:'flex', alignItems:'center', justifyContent:'center', color: socialHover===id ? 'var(--green)' : 'var(--muted)', fontFamily:'var(--fm)', fontSize:'0.72rem', textDecoration:'none', transition:'all 0.3s', cursor:'pointer' }),
    right: { maxWidth:700 },
    h2: { fontFamily:'var(--fd)', fontSize:'1.6rem', fontWeight:700, marginBottom:'1rem', color:'var(--green)' },
    p: { color:'var(--muted)', fontSize:'0.9rem', lineHeight:1.8, marginBottom:'0.8rem' },
    strong: { color:'var(--text)', fontWeight:400 },
  };

  return (
    <section style={s.section}>
      <div style={s.left}>
        <img
          src="../../assets/foto.png"
          alt="Manuel Moscariello"
          style={s.photo}
          onMouseEnter={() => setPhotoHover(true)}
          onMouseLeave={() => setPhotoHover(false)}
        />
        <div style={s.socials}>
          {[{id:'ig',label:'ig'},{id:'yt',label:'yt'}].map(({id,label}) => (
            <span
              key={id}
              style={s.socialBtn(id)}
              onMouseEnter={() => setSocialHover(id)}
              onMouseLeave={() => setSocialHover(null)}
            >{label}</span>
          ))}
        </div>
      </div>
      <div style={s.right}>
        <h2 style={s.h2}>Chi sono</h2>
        <p style={s.p}>Costruisco cose che non esistono ancora. Vado in posti dimenticati. Scrivo giochi. Suono strumenti nel modo sbagliato. <strong style={s.strong}>Preferibilmente fuori dai tracciati.</strong></p>
        <p style={s.p}>Di giorno lavoro come ecologo e presidente di <strong style={s.strong}>ASNU — Associazione Scienze Naturali Unite</strong>, dove cerco di tenere insieme natura, persone e progetti europei.</p>
        <p style={s.p}>Il resto del tempo lo passo a costruire una railbike per ferrovie abbandonate, imparare ad accendere fuochi con l'acciarino, e pianificare di scendere il Danubio su un kayak modificato da me.</p>
      </div>
    </section>
  );
};
Object.assign(window, { Profile });
