// App.jsx — main app with fake data + screen routing
const POSTS = [
  { id:1, title:'La railbike per ferrovie abbandonate', date:'mar 2025', tags:['costruzione'], cover:'../../assets/img/railbike.jpg', excerpt:'Costruire un veicolo per scorrere sui binari dimenticati del Piemonte.' },
  { id:2, title:'In bici con Lucien attraverso la Francia', date:'feb 2025', tags:['viaggi'], cover:'../../assets/img/lucien.png', excerpt:'Mille chilometri, una tenda, pochissimo piano.' },
  { id:3, title:'Come ho iniziato a suonare il bouzouki', date:'gen 2025', tags:['musica'], cover:null, excerpt:'Strumento sbagliato, tecnica sbagliata, risultato giusto.' },
  { id:4, title:'ASNU: ecologia e progetti europei', date:'dic 2024', tags:['natura'], cover:'../../assets/img/inizio.jpg', excerpt:'Cosa significa fare ecologia dal basso nel 2024.' },
  { id:5, title:'GDR con ambientazione medievale italiana', date:'nov 2024', tags:['gdr'], cover:null, excerpt:'Perché ambientare giochi di ruolo nell\'Italia comunale.' },
  { id:6, title:'Il Danubio in kayak: fase di pianificazione', date:'ott 2024', tags:['viaggi','costruzione'], cover:null, excerpt:'Prima tappa: capire se è legale.' },
];

const THOUGHTS = [
  { id:1, date:'12 apr 2026', content:'Oggi ho oliato la catena della railbike. Odore di grasso e acciaio caldo. Funziona.' },
  { id:2, date:'9 apr 2026', content:'I binari abbandonati della Val Sesia sono pieni di fiori selvatici. Non li percorrerò da solo.' },
  { id:3, date:'5 apr 2026', content:'Tre ore di bouzouki. Le dita fanno male nel modo giusto.' },
];

// Single post view
const PostView = ({ post, onBack }) => {
  const [bHover, setBHover] = React.useState(false);
  const s = {
    cover: { width:'100%', height:480, background:'var(--bg2)', position:'relative', overflow:'hidden' },
    coverImg: { width:'100%', height:'100%', objectFit:'cover', display:'block' },
    coverOverlay: { position:'absolute', inset:0, background:'linear-gradient(to bottom, transparent 65%, rgba(14,14,13,1) 100%)' },
    wrap: { maxWidth:700, margin:'0 auto', padding:'3rem 2rem 4rem' },
    back: { fontFamily:'var(--fm)', fontSize:'0.72rem', letterSpacing:'0.1em', textTransform:'uppercase', color:'var(--muted)', cursor:'pointer', marginBottom:'2.5rem', display:'block', background:'none', border:'none', padding:0 },
    backHover: { color:'var(--green)' },
    meta: { display:'flex', gap:'1rem', alignItems:'center', marginBottom:'1.5rem', flexWrap:'wrap' },
    date: { fontFamily:'var(--fm)', fontSize:'0.72rem', color:'var(--muted)' },
    tag: { fontFamily:'var(--fm)', fontSize:'0.62rem', letterSpacing:'0.12em', textTransform:'uppercase', padding:'0.2rem 0.5rem', border:'1px solid var(--green2)', color:'var(--green)' },
    title: { fontFamily:'var(--fd)', fontSize:'clamp(1.8rem,4vw,2.8rem)', fontWeight:900, color:'var(--text)', lineHeight:1.1, marginBottom:'2rem', letterSpacing:'-0.02em' },
    body: { fontFamily:'var(--fb)', fontWeight:300, fontSize:'1rem', color:'var(--muted)', lineHeight:1.9 },
    p: { marginBottom:'1.4rem' },
    strong: { color:'var(--text)', fontWeight:400 },
  };
  return (
    <>
      {post.cover && (
        <div style={s.cover}>
          <img src={post.cover} alt={post.title} style={s.coverImg} />
          <div style={s.coverOverlay} />
        </div>
      )}
      <div style={s.wrap}>
        <button style={{...s.back, ...(bHover?s.backHover:{})}} onMouseEnter={()=>setBHover(true)} onMouseLeave={()=>setBHover(false)} onClick={onBack}>← Torna alla homepage</button>
        <div style={s.meta}>
          <span style={s.date}>{post.date}</span>
          {post.tags.map(t => <span key={t} style={s.tag}>{t}</span>)}
        </div>
        <h1 style={s.title}>{post.title}</h1>
        <div style={s.body}>
          <p style={s.p}>{post.excerpt} Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla facilisi. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p>
          <p style={s.p}>Costruire qualcosa che non esiste ancora richiede di accettare l'errore come parte del processo. <strong style={s.strong}>Non si tratta di fallimento — si tratta di iterazione.</strong></p>
          <p style={s.p}>Il prossimo passo è trovare un binario abbastanza lungo e abbastanza dimenticato da poter essere usato senza disturbare nessuno.</p>
        </div>
      </div>
    </>
  );
};

const App = () => {
  const saved = (() => { try { return JSON.parse(localStorage.getItem('arteteco_state')||'{}'); } catch(e){ return {}; } })();
  const [screen, setScreen] = React.useState(saved.screen || 'home');
  const [activePost, setActivePost] = React.useState(saved.activePost || null);

  const navigate = (s, p=null) => {
    setScreen(s);
    setActivePost(p);
    localStorage.setItem('arteteco_state', JSON.stringify({screen:s, activePost:p}));
  };

  const post = activePost !== null ? POSTS.find(p => p.id === activePost) : null;

  return (
    <div style={{minHeight:'100vh', display:'flex', flexDirection:'column'}}>
      <Nav />
      {screen === 'home' && (
        <>
          <Hero />
          <Profile />
          <PostGrid posts={POSTS.map(p => ({...p, onClick: () => navigate('post', p.id)}))} onPostClick={(id) => navigate('post', id)} />
          <ThoughtsSection thoughts={THOUGHTS} />
          <Footer />
        </>
      )}
      {screen === 'post' && post && (
        <>
          <PostView post={post} onBack={() => navigate('home')} />
          <Footer />
        </>
      )}
    </div>
  );
};

// Wire up PostGrid to pass click handler properly
// Override PostGrid to support onPostClick
const _OrigPostGrid = PostGrid;
const App2 = () => {
  const saved = (() => { try { return JSON.parse(localStorage.getItem('arteteco_state')||'{}'); } catch(e){ return {}; } })();
  const [screen, setScreen] = React.useState(saved.screen || 'home');
  const [activePost, setActivePost] = React.useState(saved.activePost || null);

  const navigate = (s, p=null) => {
    setScreen(s);
    setActivePost(p);
    localStorage.setItem('arteteco_state', JSON.stringify({screen:s, activePost:p}));
    window.scrollTo(0,0);
  };

  const post = activePost !== null ? POSTS.find(p => p.id === activePost) : null;
  const allTags = [...new Set(POSTS.flatMap(p => p.tags))].sort();
  const [activeTag, setActiveTag] = React.useState('tutti');
  const visible = activeTag === 'tutti' ? POSTS : POSTS.filter(p => p.tags.includes(activeTag));

  const gridS = {
    section: { padding:'3rem 2rem', maxWidth:'1100px', margin:'0 auto' },
    header: { display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'2rem', flexWrap:'wrap', gap:'1rem' },
    label: { fontFamily:'var(--fm)', fontSize:'0.72rem', letterSpacing:'0.3em', textTransform:'uppercase', color:'var(--green)' },
    filters: { display:'flex', gap:'0.5rem', flexWrap:'wrap' },
    filterBtn: (active) => ({ fontFamily:'var(--fm)', fontSize:'0.68rem', letterSpacing:'0.12em', textTransform:'uppercase', color: active ? 'var(--green)' : 'var(--muted)', border:`1px solid ${active ? 'var(--green)' : 'var(--border)'}`, padding:'0.3rem 0.7rem', cursor:'pointer', transition:'all 0.3s', background:'none' }),
    grid: { display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'1px', background:'var(--border)' },
  };

  return (
    <div style={{minHeight:'100vh', display:'flex', flexDirection:'column'}}>
      <Nav onLogoClick={() => navigate('home')} />
      {screen === 'home' && (
        <>
          <Profile />
          <section style={gridS.section}>
            <div style={gridS.header}>
              <p style={gridS.label}>// Tutto</p>
              <div style={gridS.filters}>
                {['tutti', ...allTags].map(tag => (
                  <button key={tag} style={gridS.filterBtn(activeTag===tag)} onClick={()=>setActiveTag(tag)}>{tag}</button>
                ))}
              </div>
            </div>
            <div style={gridS.grid}>
              {visible.map(p => <PostCard key={p.id} post={p} onClick={() => navigate('post', p.id)} />)}
            </div>
          </section>
          <ThoughtsSection thoughts={THOUGHTS} />
          <Footer />
        </>
      )}
      {screen === 'post' && post && (
        <>
          <PostView post={post} onBack={() => navigate('home')} />
          <Footer />
        </>
      )}
    </div>
  );
};

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App2 />);
